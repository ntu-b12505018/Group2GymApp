package sc;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class LoginPanel extends JPanel {
    private GymManagementSystem system;
    private JTextField emailField       = new JTextField(15);
    private JPasswordField pwdField     = new JPasswordField(15);
    private JButton loginButton         = new JButton("會員登入");
    private JButton toRegisterButton    = new JButton("去註冊");
    private JButton adminLoginButton    = new JButton("管理員登入");

    private BufferedImage backgroundImg;

    public LoginPanel(GymManagementSystem system) {
        this.system = system;
        loadBackgroundImage();

        setLayout(new BorderLayout());

        // === 上方標題 ===
        JLabel title = new JLabel("會員登入", SwingConstants.CENTER);
        title.setFont(new Font("微軟正黑體", Font.BOLD, 28));
        title.setForeground(new Color(40, 70, 120));
        title.setOpaque(true);
        title.setBackground(new Color(255, 255, 255, 200));  // 半透明白底
        title.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(100, 100, 150), 2),
            BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));
        add(title, BorderLayout.NORTH);

        // === 中央表單區塊 ===
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setOpaque(false); // 透明背景，讓背景圖透出

     // === Email 欄 ===
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        emailLabel.setFont(new Font("微軟正黑體", Font.PLAIN, 16));
        emailLabel.setOpaque(true);
        emailLabel.setBackground(new Color(255, 255, 255, 230)); // 半透明白底
        emailLabel.setBorder(BorderFactory.createEmptyBorder(4, 10, 4, 10));

        emailField.setMaximumSize(new Dimension(200, 30));
        emailField.setAlignmentX(Component.CENTER_ALIGNMENT);
        emailField.setOpaque(true);
        emailField.setBackground(new Color(255, 255, 255, 230)); // 白色背景
        emailField.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        // === 密碼欄 ===
        JLabel pwdLabel = new JLabel("密碼:");
        pwdLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        pwdLabel.setFont(new Font("微軟正黑體", Font.PLAIN, 16));
        pwdLabel.setOpaque(true);
        pwdLabel.setBackground(new Color(255, 255, 255, 230));
        pwdLabel.setBorder(BorderFactory.createEmptyBorder(4, 10, 4, 10));

        pwdField.setMaximumSize(new Dimension(200, 30));
        pwdField.setAlignmentX(Component.CENTER_ALIGNMENT);
        pwdField.setOpaque(true);
        pwdField.setBackground(new Color(255, 255, 255, 230));
        pwdField.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        // 按鈕
        loginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        toRegisterButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        adminLoginButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        loginButton.setBackground(new Color(70, 130, 180));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);

        // 加入元件與間距
        formPanel.add(emailLabel);
        formPanel.add(emailField);
        formPanel.add(Box.createVerticalStrut(10));
        formPanel.add(pwdLabel);
        formPanel.add(pwdField);
        formPanel.add(Box.createVerticalStrut(20));
        formPanel.add(loginButton);
        formPanel.add(Box.createVerticalStrut(10));
        formPanel.add(toRegisterButton);
        formPanel.add(Box.createVerticalStrut(10));
        formPanel.add(adminLoginButton);

        add(formPanel, BorderLayout.CENTER);
    }

    /** 背景圖繪製（自動縮放） */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImg != null) {
            // 自動縮放背景圖至整個面板大小
            g.drawImage(backgroundImg, 0, 0, getWidth(), getHeight(), this);
        }
    }

    /** 載入背景圖檔（請確保圖片存在） */
    private void loadBackgroundImage() {
        try {
            backgroundImg = ImageIO.read(new File("C:/OOP/gym/src/sc/login.jpg"));
        } catch (IOException e) {
            System.err.println("背景圖片載入失敗: " + e.getMessage());
        }
    }

    // --- Getter methods ---
    public JButton getLoginButton()      { return loginButton; }
    public JButton getToRegisterButton() { return toRegisterButton; }
    public JButton getAdminLoginButton() { return adminLoginButton; }
    public String  getUsername()         { return emailField.getText(); }
    public String  getPassword()         { return new String(pwdField.getPassword()); }
}

