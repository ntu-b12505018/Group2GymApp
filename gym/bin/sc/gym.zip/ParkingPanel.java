package sc;

import javax.swing.*;
import java.util.*;
import sc.Course;

public class ParkingPanel extends JPanel {
    private GymManagementSystem system;
    private JComboBox<ParkingPlan> planCombo = new JComboBox<>();
    private JButton purchaseButton = new JButton("購買停車");

    public ParkingPanel(GymManagementSystem system) {
        this.system = system;
        add(new JLabel("選擇方案："));
        // TODO: 先前沒提供 getParkingPlans()，可自己新增或之後再補
        // for (ParkingPlan p: system.getParkingPlans()) planCombo.addItem(p);
        add(planCombo);
        add(purchaseButton);
    }

    public JButton     getPurchaseButton() { return purchaseButton; }
    public ParkingPlan getPlan()           { return (ParkingPlan)planCombo.getSelectedItem(); }
    public void refresh() {
        planCombo.removeAllItems();
        for (ParkingPlan p : system.getParkingPlans()) {
            planCombo.addItem(p);
        }
    }
}
