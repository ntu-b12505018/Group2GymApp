package sc;

import javax.swing.*;
import sc.Course;

public class ClubViewPanel extends JPanel {
    private GymManagementSystem system;
    private JButton enrollCourseButton    = new JButton("報名課程");
    private JButton purchaseParkingButton = new JButton("購買停車");

    public ClubViewPanel(GymManagementSystem system) {
        this.system = system;
        add(new JLabel("請選擇："));
        add(enrollCourseButton);
        add(purchaseParkingButton);
    }

    public JButton getEnrollCourseButton()    { return enrollCourseButton; }
    public JButton getPurchaseParkingButton() { return purchaseParkingButton; }

    public void refresh() {
        // TODO: 每次顯示前更新可報名課程或停車方案
    }
}
