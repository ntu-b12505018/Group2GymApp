package sc;

import java.util.Date;

public class Attendance {
    private String memberId;
    private Date   checkInTime;

    public Attendance(String memberId, Date checkInTime) {
        this.memberId    = memberId;
        this.checkInTime = checkInTime;
    }

    public String getMemberId()    { return memberId; }
    public Date   getCheckInTime() { return checkInTime; }

    @Override
    public String toString() {
        return memberId + " 打卡於 " + checkInTime;
    }
}
