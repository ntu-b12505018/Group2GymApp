package sc;

import javax.swing.*;
import java.util.Date;

public class PaymentPanel extends JPanel {
    private final GymManagementSystem system;
    private final JTextField amountField = new JTextField(10);
    private final JButton    payButton   = new JButton("付款");

    public PaymentPanel(GymManagementSystem system) {
        this.system = system;
        add(new JLabel("金額："));
        add(amountField);
        add(payButton);
    }

    public JButton getPayButton() {
        return payButton;
    }

    /** 由使用者輸入產生 Payment 物件 */
    public Payment getPaymentData() {
        double amt      = Double.parseDouble(amountField.getText());
        String memberId = system.getCurrentMemberId();
        return new Payment(memberId, amt, new Date());
    }

    /** 在欄位上顯示應付金額 */
    public void setAmount(double fee) {
        amountField.setText(String.valueOf(fee));
    }
}
