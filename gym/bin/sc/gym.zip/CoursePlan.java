package sc;

/**
 * (如果你有自己的課表邏輯，把它搬進來，否則先留空)
 */

public class CoursePlan {
    private String name;
    private double price;

    public CoursePlan(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() { return name; }
    public double getPrice() { return price; }
}