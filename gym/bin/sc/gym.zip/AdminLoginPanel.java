package sc;

import javax.swing.*;

public class AdminLoginPanel extends JPanel {
    private GymManagementSystem system;
    private JTextField userField   = new JTextField(10);
    private JPasswordField pwdField= new JPasswordField(10);
    private JButton loginButton    = new JButton("管理員登入");
    private JButton backButton     = new JButton("返回");

    public AdminLoginPanel(GymManagementSystem system) {
        this.system = system;
        add(new JLabel("帳號："));    add(userField);
        add(new JLabel("密碼："));    add(pwdField);
        add(loginButton);
        add(backButton);
    }

    public JButton getLoginButton() { return loginButton; }
    public JButton getBackButton()  { return backButton;  }
    public String  getUsername()    { return userField.getText(); }
    public String  getPassword()    { return new String(pwdField.getPassword()); }
}
