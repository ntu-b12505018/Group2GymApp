package sc;

import java.util.Set;
import java.util.*;	

public class Member {
    private String memberId, name, email, password;
    private Set<Region> regions;
    
    private List<Course>      enrolledCourses = new ArrayList<>();
    private List<ParkingPlan> parkingPlans    = new ArrayList<>();

    public Member(String memberId, String name, String email, String password, Set<Region> regions) {
        this.memberId = memberId;
        this.name     = name;
        this.email    = email;
        this.password = password;
        this.regions  = regions;
    }

    public String getMemberId()           { return memberId; }
    public String getName()               { return name; }
    public String getEmail()              { return email; }
    public String getId()       { return memberId; }
    public String getPassword() { return password; }
    
    public boolean authenticate(String p) { return password.equals(p); }
    public boolean canAccessRegion(Region r) {
        return regions.contains(r) || regions.contains(Region.ALL);
    }
    
    public List<Course>      getEnrolledCourses() { return enrolledCourses; }
    public List<ParkingPlan> getParkingPlans()    { return parkingPlans; }

    
    @Override
    public String toString() {
        return memberId + "：" + name;
    }
}
