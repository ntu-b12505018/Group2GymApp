package sc;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class GymManagementSystem {
    private List<Member> members;
    private List<Course> courses;
    private List<Attendance> attendanceRecords;
    private List<Payment> payments;
    private List<GymClub> gymClubs;
    private List<ParkingPlan> parkingPlans;
    private Member currentUser;

    public GymManagementSystem() {
        members = new ArrayList<>();
        courses = new ArrayList<>();
        attendanceRecords = new ArrayList<>();
        payments = new ArrayList<>();
        gymClubs = new ArrayList<>();
        parkingPlans = new ArrayList<>();
        loadSampleData();
    }

    private void loadSampleData() {
        courses.add(new Course("C001", "瑜珈課程", "Instructor A", "週一 10:00"));
        courses.add(new Course("C002", "有氧運動", "Instructor B", "週三 18:00"));

        for (Region r : Region.values()) {
            for (int i = 1; i <= 5; i++) {
                String clubId = r.toString().substring(0, 1) + "0" + i;
                gymClubs.add(new GymClub(clubId, r + " 健身房 #" + i, r));
            }
        }

        members.add(new Member("M001", "Alice", "alice@example.com", "password123", Set.of(Region.NORTH)));
        members.add(new Member("M002", "Bob", "bob@example.com", "bobpass", Set.of(Region.SOUTH)));
        members.add(new Member("M999", "Global", "all@example.com", "freepass", Set.of(Region.values())));

        // 初始化停車方案
        parkingPlans.add(new ParkingPlan("月租A", "Alice",1000));
        parkingPlans.add(new ParkingPlan("季租B", "Bob",2700));
    }

    // --------- 為 GUI 提供的方法 ---------
    /**
     * 會員註冊
     */
    private int memberSeq = 3;              // 已有 M001~M003
    
    public int getNextMemberSeq(){ return ++memberSeq; }
    public boolean registerMember(Member m){
        for(Member x : members){
            if(x.getEmail().equalsIgnoreCase(m.getEmail())) return false;
        }
        return members.add(m);
    }

    /**
     * 會員登入，並設定當前會員
     */
    public boolean login(String account, String pwd){
        for(Member m : members){
            boolean okAccount = account.equalsIgnoreCase(m.getMemberId()) ||
                                account.equalsIgnoreCase(m.getEmail());
            if(okAccount && m.authenticate(pwd)){ currentUser = m; return true; }
        }
        return false;
    }

    /**
     * 取得當前會員 ID，供 GUI 組裝付款資料
     */
    public String getCurrentMemberId() {
        return currentUser != null ? currentUser.getId() : null;
    }

    /**
     * 管理員登入
     */
    public boolean loginAdmin(String username, String pwd) {
        return "admin".equals(username) && "1234".equals(pwd);
    }

    /**
     * 報名課程
     */
    public boolean enrollCourse(Course c) {
        if (currentUser == null) return false;
        return currentUser.getEnrolledCourses().add(c);
    }

    /**
     * 取得課程費用
     */
    public double getCourseFee(Course c) {
        return c.getFee();
    }

    /**
     * 取得所有停車方案
     */
    public List<ParkingPlan> getParkingPlans() {
        return parkingPlans;
    }

    /**
     * 購買停車方案
     */
    public boolean purchaseParking(ParkingPlan p) {
        if (currentUser == null) return false;
        return currentUser.getParkingPlans().add(p);
    }

    /**
     * 處理付款
     */
    public boolean processPayment(Payment pay) {
        payments.add(pay);
        return true;
    }

    // --------- 控制台舊版互動方法，可保留或移除 ---------
    public Member findMemberByEmail(String email) {
        for (Member m : members) {
            if (m.getEmail().equalsIgnoreCase(email)) return m;
        }
        return null;
    }

    public void memberLogin() {
        Scanner sc = new Scanner(System.in);
        System.out.print("請輸入電子郵件: ");
        String email = sc.nextLine();
        Member member = findMemberByEmail(email);
        if (member == null) {
            System.out.println("查無此會員！");
            return;
        }
        System.out.print("請輸入密碼: ");
        String pwd = sc.nextLine();
        if (member.authenticate(pwd)) {
            System.out.println("歡迎光臨, " + member.getName() + "!");
            memberOperations(member);
        } else {
            System.out.println("密碼不正確。");
        }
    }

    public void memberOperations(Member member) {
        Scanner sc = new Scanner(System.in);
        boolean exit = false;
        while (!exit) {
            System.out.println("\n【會員操作選單】");
            System.out.println("1. 查看課程");
            System.out.println("2. 報名課程");
            System.out.println("3. 考勤打卡");
            System.out.println("4. 付款");
            System.out.println("5. 查看授權俱樂部");
            System.out.println("6. 登出");
            System.out.print("請選擇操作: ");
            String choice = sc.nextLine();
            switch (choice) {
                case "1" -> viewCourses();
                case "2" -> signUpCourse(member);
                case "3" -> checkIn(member);
                case "4" -> makePayment(member);
                case "5" -> showAccessibleClubs(member);
                case "6" -> exit = true;
                default -> System.out.println("選項無效！");
            }
        }
    }

    public void viewCourses() {
        System.out.println("\n【課程列表】");
        for (Course c : courses) {
            System.out.println(c);
        }
    }

    public void signUpCourse(Member member) {
        viewCourses();
        Scanner sc = new Scanner(System.in);
        System.out.print("請輸入要報名的課程編號: ");
        String courseId = sc.nextLine();
        Course selected = null;
        for (Course c : courses) {
            if (c.getCourseId().equalsIgnoreCase(courseId)) {
                selected = c;
                break;
            }
        }
        if (selected != null) {
            member.getEnrolledCourses().add(selected);
            System.out.println(member.getName() + " 已成功報名課程: " + selected.getTitle());
        } else {
            System.out.println("查無此課程。" );
        }
    }

    public void checkIn(Member member) {
        Attendance record = new Attendance(member.getMemberId(), new Date());
        attendanceRecords.add(record);
        System.out.println("打卡成功：" + record);
    }

    public void makePayment(Member member) {
        Scanner sc = new Scanner(System.in);
        System.out.print("請輸入付款金額: ");
        double amount = sc.nextDouble();
        Payment pay = new Payment(member.getMemberId(), amount, new Date());
        payments.add(pay);
        System.out.println("付款成功：" + pay);
    }

    public void memberRegistration() {
        Scanner sc = new Scanner(System.in);
        System.out.print("輸入會員ID: ");
        String id = sc.nextLine();
        System.out.print("輸入姓名: ");
        String name = sc.nextLine();
        System.out.print("輸入電子郵件: ");
        String email = sc.nextLine();
        System.out.print("設定密碼: ");
        String pwd = sc.nextLine();
        System.out.print("輸入地區代碼 (N/S/E/W/ALL): ");
        String regionInput = sc.nextLine().toUpperCase();
        Set<Region> regions;
        switch (regionInput) {
            case "N" -> regions = Set.of(Region.NORTH);
            case "S" -> regions = Set.of(Region.SOUTH);
            case "E" -> regions = Set.of(Region.EAST);
            case "W" -> regions = Set.of(Region.WEST);
            case "ALL" -> regions = Set.of(Region.values());
            default -> regions = Set.of(Region.NORTH);
        }
        members.add(new Member(id, name, email, pwd, regions));
        System.out.println("註冊成功：" + name);
    }

    public void showAccessibleClubs(Member member) {
        System.out.println("\n您可使用的健身俱樂部：");
        for (GymClub club : gymClubs) {
            if (member.canAccessRegion(club.getRegion())) {
                System.out.println(club);
            }
        }
    }

    public static void main(String[] args) {
        GymManagementSystem system = new GymManagementSystem();
        system.memberLogin();
    }

    public List<GymClub> getGymClubs() {
        return gymClubs;
    }

    public List<Member> getMembers() {
        return members;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public List<Payment> getPayments() {
        return payments;
    }

    public List<Attendance> getAttendanceRecords() {
        return attendanceRecords;
    }
}
