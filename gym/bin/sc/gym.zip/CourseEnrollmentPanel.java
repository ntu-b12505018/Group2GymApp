package sc;

import javax.swing.*;
import java.util.*;
import sc.Course; 

public class CourseEnrollmentPanel extends JPanel {
    private GymManagementSystem system;
    private JComboBox<Course> courseCombo = new JComboBox<>();
    private JButton enrollButton    = new JButton("確定報名");
    private JButton toPaymentButton = new JButton("去付款");

    public CourseEnrollmentPanel(GymManagementSystem system) {
        this.system = system;
        add(new JLabel("選擇課程："));
        add(courseCombo);
        add(enrollButton);
        add(toPaymentButton);
    }

    public void refresh() {
        courseCombo.removeAllItems();
        for (Course c : system.getCourses()) {
            courseCombo.addItem(c);
        }
    }

    public JButton getEnrollButton()    { return enrollButton; }
    public JButton getToPaymentButton() { return toPaymentButton; }
    public Course  getSelectedCourse()  { return (Course)courseCombo.getSelectedItem(); }
}
