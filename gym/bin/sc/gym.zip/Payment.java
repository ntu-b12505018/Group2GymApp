package sc;

import java.util.Date;

public class Payment {
    private String memberId;
    private double amount;
    private Date   paymentDate;

    public Payment(String memberId, double amount, Date paymentDate) {
        this.memberId    = memberId;
        this.amount      = amount;
        this.paymentDate = paymentDate;
    }

    public String getMemberId()    { return memberId; }
    public double getAmount()      { return amount; }
    public Date   getPaymentDate() { return paymentDate; }

    @Override
    public String toString() {
        return memberId + " 付款 " + amount + " 於 " + paymentDate;
    }
}
