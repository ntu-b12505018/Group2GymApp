package sc;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.EnumSet;
import java.util.Set;
import java.util.regex.Pattern;
import javax.swing.border.Border;


public class RegistrationPanel extends JPanel {
    private final GymManagementSystem system;

    private final JTextField nameField   = new JTextField(16);
    private final JTextField emailField  = new JTextField(18);
    private final JPasswordField pwdField = new JPasswordField(18);

    private final JCheckBox northBox = new JCheckBox("North");
    private final JCheckBox southBox = new JCheckBox("South");
    private final JCheckBox eastBox  = new JCheckBox("East");
    private final JCheckBox westBox  = new JCheckBox("West");

    private final JButton registerBtn = new JButton("註冊");
    private final JButton toLoginBtn  = new JButton("返回登入");

    private static final Pattern PWD_STRONG = Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{8,}$");
    private static final Pattern EMAIL_FMT  = Pattern.compile("^[\\w.%+-]+@[\\w.-]+\\.[A-Za-z]{2,}$");

    private Image backgroundImage;

    public RegistrationPanel(GymManagementSystem system) {
        this.system = system;
        loadBackgroundImage();
        buildUI();
    }

    private void loadBackgroundImage() {
        ImageIcon icon = new ImageIcon("C:\\OOP\\gym\\src\\sc\\registration.jpg");
        backgroundImage = icon.getImage();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }

    public JButton getRegisterButton() { return registerBtn; }
    public JButton getToLoginButton() { return toLoginBtn; }

    public Member getMemberData() {
        String id = "M" + String.format("%03d", system.getNextMemberSeq());
        String name = nameField.getText().trim();
        String mail = emailField.getText().trim();
        String pwd  = new String(pwdField.getPassword());
        Set<Region> regions = getSelectedRegions();
        return new Member(id, name, mail, pwd, regions);
    }

    public boolean isInputValid() {
        String name = nameField.getText().trim();
        String mail = emailField.getText().trim();
        String pwd  = new String(pwdField.getPassword());

        return !(name.isEmpty() || mail.isEmpty() || pwd.isEmpty()) &&
                EMAIL_FMT.matcher(mail).matches() &&
                PWD_STRONG.matcher(pwd).matches() &&
                !getSelectedRegions().isEmpty();
    }

    private Set<Region> getSelectedRegions() {
        EnumSet<Region> set = EnumSet.noneOf(Region.class);
        if (northBox.isSelected()) set.add(Region.NORTH);
        if (southBox.isSelected()) set.add(Region.SOUTH);
        if (eastBox.isSelected())  set.add(Region.EAST);
        if (westBox.isSelected())  set.add(Region.WEST);
        return set;
    }

    private void buildUI() {
        setLayout(new BorderLayout(12, 12));
        setBorder(new EmptyBorder(24, 32, 24, 32));  // 外圍留白更大一點

        Border labelBorder = BorderFactory.createLineBorder(Color.GRAY);

        // ---------- 表單區 ----------
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);  // 背景透明
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 4, 8, 4);
        gbc.anchor = GridBagConstraints.WEST;

        // 第一列：姓名
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(createLabelPanel("姓名", labelBorder), gbc);
        gbc.gridx = 1;
        formPanel.add(nameField, gbc);

        // 第二列：Email
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(createLabelPanel("Email", labelBorder), gbc);
        gbc.gridx = 1;
        formPanel.add(emailField, gbc);

        // 第三列：密碼
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(createLabelPanel("密碼", labelBorder), gbc);
        gbc.gridx = 1;
        formPanel.add(pwdField, gbc);

        // 第四列：可用地區（多個 checkbox）
        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(createLabelPanel("可用地區", labelBorder), gbc);
        gbc.gridx = 1;
        JPanel regionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        regionPanel.setOpaque(false);
        regionPanel.add(northBox);
        regionPanel.add(southBox);
        regionPanel.add(eastBox);
        regionPanel.add(westBox);
        formPanel.add(regionPanel, gbc);

        add(formPanel, BorderLayout.CENTER);

        // ---------- 按鈕區 ----------
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setOpaque(false);
        buttonPanel.add(registerBtn);
        buttonPanel.add(toLoginBtn);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    // 給 Label 加上邊框與底色
    private JPanel createLabelPanel(String text, Border border) {
        JPanel labelPanel = new JPanel();
        labelPanel.setBackground(new Color(255, 255, 255, 200));  // 白底、略透明
        labelPanel.setBorder(border);
        labelPanel.add(new JLabel(text));
        return labelPanel;
    }


}


