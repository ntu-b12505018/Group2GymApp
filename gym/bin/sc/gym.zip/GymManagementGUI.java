package sc;

import javax.swing.*;
import java.awt.*;
import sc.RegistrationPanel;
import sc.LoginPanel;
import sc.ClubViewPanel;
import sc.CourseEnrollmentPanel;
import sc.ParkingPanel;
import sc.PaymentPanel;
import sc.AdminLoginPanel;
import sc.AdminPanel;
import sc.ConsentDialog;


public class GymManagementGUI extends JFrame {
    private CardLayout cardLayout;
    private JPanel      cardPanel;
    private GymManagementSystem system;

    // 各個分頁
    private RegistrationPanel     regPanel;
    private LoginPanel            loginPanel;
    private ClubViewPanel         clubPanel;
    private CourseEnrollmentPanel coursePanel;
    private ParkingPanel          parkingPanel;
    private PaymentPanel          paymentPanel;
    private AdminLoginPanel       adminLoginPanel;
    private AdminPanel            adminPanel;
    private ConsentDialog         consentDialog;

    public GymManagementGUI(GymManagementSystem system) {
        super("健身房管理系統");
        this.system = system;
        initGUI();
    }

    private void initGUI() {
        cardLayout = new CardLayout();
        cardPanel  = new JPanel(cardLayout);

        // 初始化各頁面
        regPanel     = new RegistrationPanel(system);
        loginPanel   = new LoginPanel(system);
        clubPanel    = new ClubViewPanel(system);
        coursePanel  = new CourseEnrollmentPanel(system);
        parkingPanel = new ParkingPanel(system);
        paymentPanel = new PaymentPanel(system);
        adminLoginPanel = new AdminLoginPanel(system);
        adminPanel   = new AdminPanel(system);
        consentDialog = new ConsentDialog(this);

        // 加入卡片，名稱務必對應下面 show() 用的 key
        cardPanel.add(regPanel,    "register");
        cardPanel.add(loginPanel,  "login");
        cardPanel.add(clubPanel,   "clubView");
        cardPanel.add(coursePanel, "courseEnroll");
        cardPanel.add(parkingPanel,"parking");
        cardPanel.add(paymentPanel,"payment");
        cardPanel.add(adminLoginPanel,  "adminLogin");
        cardPanel.add(adminPanel,  "adminPanel");

        // --- 監聽器設置 ---
        // 註冊頁 --> 登入頁
        regPanel.getToLoginButton().addActionListener(e -> {
            cardLayout.show(cardPanel, "login");
        });
        // 真正執行註冊 (含同意書)
        regPanel.getRegisterButton().addActionListener(e -> {
            consentDialog.setModal(true);
            consentDialog.setVisible(true);
            if (!consentDialog.isAccepted()) {
                JOptionPane.showMessageDialog(this, "請先同意使用條款");
                return;
            }
            Member m = regPanel.getMemberData();
            if (system.registerMember(m)) {
                JOptionPane.showMessageDialog(this, "註冊成功，請登入");
                cardLayout.show(cardPanel, "login");
            } else {
                JOptionPane.showMessageDialog(this, "註冊失敗");
            }
        });

        // 登入頁 <--> 註冊頁
        loginPanel.getToRegisterButton().addActionListener(e -> {
            cardLayout.show(cardPanel, "register");
        });
        loginPanel.getLoginButton().addActionListener(e -> {
            String id  = loginPanel.getUsername();
            String pwd = loginPanel.getPassword();
            if (system.login(id, pwd)) {
                // 登入成功後顯示會所頁，並更新資料
                clubPanel.refresh();
                cardLayout.show(cardPanel, "clubView");
            } else {
                JOptionPane.showMessageDialog(this, "帳號或密碼錯誤");
            }
        });

        // 會員登入頁 --> 管理員登入頁
        loginPanel.getAdminLoginButton().addActionListener(e -> {
            cardLayout.show(cardPanel, "adminLogin");
        });
        // 會所頁 --> 報名課程 / 購買停車
        clubPanel.getEnrollCourseButton().addActionListener(e -> {
            coursePanel.refresh();
            cardLayout.show(cardPanel, "courseEnroll");
        });
        clubPanel.getPurchaseParkingButton().addActionListener(e -> {
            parkingPanel.refresh();
            cardLayout.show(cardPanel, "parking");
        });

        // 報名課程頁 --> 確定 / 去付款
        coursePanel.getEnrollButton().addActionListener(e -> {
            Course c = coursePanel.getSelectedCourse();
            if (system.enrollCourse(c)) {
                JOptionPane.showMessageDialog(this, "課程報名成功");
            } else {
                JOptionPane.showMessageDialog(this, "課程報名失敗");
            }
        });
        coursePanel.getToPaymentButton().addActionListener(e -> {
            double fee = system.getCourseFee(coursePanel.getSelectedCourse());
            paymentPanel.setAmount(fee);
            cardLayout.show(cardPanel, "payment");
        });

        // 停車方案頁 --> 購買
        parkingPanel.getPurchaseButton().addActionListener(e -> {
            ParkingPlan p = parkingPanel.getPlan();
            if (system.purchaseParking(p)) {
                JOptionPane.showMessageDialog(this, "購買停車成功");
            } else {
                JOptionPane.showMessageDialog(this, "購買停車失敗");
            }
            // 購買後可直接去付款
            paymentPanel.setAmount(p.getPrice());
            cardLayout.show(cardPanel, "payment");
        });

        // 付款頁 --> 付款
        paymentPanel.getPayButton().addActionListener(e -> {
            Payment pay = paymentPanel.getPaymentData();
            if (system.processPayment(pay)) {
                JOptionPane.showMessageDialog(this, "付款成功");
                clubPanel.refresh();
                cardLayout.show(cardPanel, "clubView");
            } else {
                JOptionPane.showMessageDialog(this, "付款失敗");
            }
        });

        // 管理員登入頁 --> 管理頁面
        adminLoginPanel.getLoginButton().addActionListener(e -> {
            String u = adminLoginPanel.getUsername();
            String p = adminLoginPanel.getPassword();
            if (system.loginAdmin(u, p)) {
                adminPanel.refresh();
                cardLayout.show(cardPanel, "adminPanel");
            } else {
                JOptionPane.showMessageDialog(this, "管理員帳號或密碼錯誤");
            }
        });

        adminLoginPanel.getBackButton().addActionListener(e -> {
            cardLayout.show(cardPanel, "login");
        });
        // 加入主容器並顯示
        setContentPane(cardPanel);
        setSize(900,600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        // 預設先顯示註冊頁
        cardLayout.show(cardPanel, "register");
        setVisible(true);
        

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GymManagementGUI(new GymManagementSystem()));
    }
}

