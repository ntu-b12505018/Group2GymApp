package sc;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.*;
import sc.Course;

public class AdminPanel extends JPanel {
    private GymManagementSystem system;

    private DefaultTableModel memberModel;
    private JTable            memberTable;
    private DefaultTableModel clubModel;
    private JTable            clubTable;
    private DefaultTableModel courseModel;
    private JTable            courseTable;
    private DefaultTableModel paymentModel;
    private JTable            paymentTable;
    private DefaultTableModel attendanceModel;
    private JTable            attendanceTable;

    public AdminPanel(GymManagementSystem system) {
        this.system = system;
        setLayout(new BorderLayout());

        JTabbedPane tabs = new JTabbedPane();

        // 會員
        memberModel = new DefaultTableModel(new String[]{"會員ID","姓名","Email"},0);
        memberTable = new JTable(memberModel);
        tabs.addTab("會員管理", new JScrollPane(memberTable));

        // 俱樂部
        clubModel = new DefaultTableModel(new String[]{"俱樂部ID","名稱","地區"},0);
        clubTable = new JTable(clubModel);
        tabs.addTab("俱樂部管理", new JScrollPane(clubTable));

        // 課程
        courseModel = new DefaultTableModel(new String[]{"課程ID","標題","教練","時間"},0);
        courseTable = new JTable(courseModel);
        tabs.addTab("課程管理", new JScrollPane(courseTable));

        // 付款
        paymentModel = new DefaultTableModel(new String[]{"會員ID","金額","日期"},0);
        paymentTable = new JTable(paymentModel);
        tabs.addTab("付款紀錄", new JScrollPane(paymentTable));

        // 出席
        attendanceModel = new DefaultTableModel(new String[]{"會員ID","打卡時間"},0);
        attendanceTable = new JTable(attendanceModel);
        tabs.addTab("出席紀錄", new JScrollPane(attendanceTable));

        add(tabs, BorderLayout.CENTER);
        refresh();
    }

    public void refresh() {
        // 會員
        memberModel.setRowCount(0);
        for (Member m : system.getMembers()) {
            memberModel.addRow(new Object[]{m.getMemberId(), m.getName(), m.getEmail()});
        }
        // 俱樂部
        clubModel.setRowCount(0);
        for (GymClub c: system.getGymClubs()) {
            clubModel.addRow(new Object[]{c.getClubId(), c.getName(), c.getRegion()});
        }
        // 課程
        courseModel.setRowCount(0);
        for (Course c: system.getCourses()) {
            courseModel.addRow(new Object[]{c.getCourseId(), c.getTitle(), c.getInstructor(), c.getSchedule()});
        }
        // 付款
        paymentModel.setRowCount(0);
        for (Payment p: system.getPayments()) {
            paymentModel.addRow(new Object[]{p.getMemberId(), p.getAmount(), p.getPaymentDate()});
        }
        // 出席
        attendanceModel.setRowCount(0);
        for (Attendance a: system.getAttendanceRecords()) {
            attendanceModel.addRow(new Object[]{a.getMemberId(), a.getCheckInTime()});
        }
    }
}
