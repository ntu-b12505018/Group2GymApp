package sc;

public class Course {
    private String courseId, title, instructor, schedule;
    private double fee;
    
    public Course(String courseId, String title, String instructor, String schedule) {
        this.courseId   = courseId;
        this.title      = title;
        this.instructor = instructor;
        this.schedule   = schedule;
    }
    
    public Course(String courseId, String title, String instructor, String schedule, double fee) {
        this.courseId   = courseId;
        this.title      = title;
        this.instructor = instructor;
        this.schedule   = schedule;
        this.fee        = fee;
    }

    public String getCourseId()   { return courseId; }
    public String getTitle()      { return title; }
    public String getInstructor(){ return instructor; }
    public String getSchedule()   { return schedule; }
    public double getFee()      { return fee; } 

    @Override
    public String toString() {
        return courseId + " " + title;
    }
}
