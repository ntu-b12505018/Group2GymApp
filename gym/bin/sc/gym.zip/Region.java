package sc;

public enum Region {
    NORTH, SOUTH, EAST, WEST, ALL   // ← 新增 ALL
}
